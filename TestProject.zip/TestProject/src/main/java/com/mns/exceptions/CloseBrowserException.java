package com.mns.exceptions;

public class CloseBrowserException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CloseBrowserException(String message) {
		super(message);
	}

}
