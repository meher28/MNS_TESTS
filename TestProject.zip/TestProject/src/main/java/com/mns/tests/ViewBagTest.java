package com.mns.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewBagTest {

	WebDriver ff;

	@Given("^I have added a \"([^\"]*)\" to my bag$")
	public void i_have_added_a_shirt_to_my_bag(String shirtName)
			throws Throwable {
		ff = new FirefoxDriver();
		ff.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ff.manage().window().maximize();
		ff.get("http://www.marksandspencer.com");
		List<WebElement> navigationItems = ff.findElements(By
				.xpath("//div[@id='main-nav']/nav/ul/li/a/span"));
		WebElement tempElement = null;
		Actions action = new Actions(ff);
		for (WebElement item : navigationItems) {
			System.out.println(item.getText());
			if (item.getText().equals("MEN")) {
				item.click();
				tempElement = item;
				break;
			}
		}
		action.moveToElement(ff.findElement(By.linkText("Formal Shirts")));
		action.click();
		action.build().perform();
		List<WebElement> productNames = ff.findElements(By
				.xpath("//div[@id='product-listing']/form/ol/li/div[2]/h3/a"));

		for (WebElement productName : productNames) {
			System.out.println(productName.getText());
			if (productName.getText().equalsIgnoreCase(shirtName)) {
				productName.click();
				break;
			}
		}

	}

	@When("^I view the contents of my bag$")
	public void i_view_the_contents_of_my_bag() throws Throwable {

		ff.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		List<WebElement> sizes = ff
				.findElements(By
						.xpath("//div[@class='size-table']/div/div/table/tbody/tr/td/label"));
		for (WebElement size : sizes) {
			if (size.getText().equalsIgnoreCase("15")) {
				size.click();
				break;
			}
		}
		ff.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		ff.findElement(By.xpath("//*[@value='add to bag']")).click();
		ff.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		ff.findElement(
				By.xpath("//*[@id='headerSection']/nav/ul/li[3]/ul/li/a/span[2]"))
				.click();
		ff.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@Then("^I can see the contents of the bag include a \"([^\"]*)\"$")
	public void i_can_see_the_contents_of_the_bag_include_a_shirt(
			String shirtName) throws Throwable {
		List<WebElement> basketitems = ff
				.findElements(By
						.xpath("//*[@class='order-details-wrapper']/table/tbody/tr/td[1]/section/div[1]/h3/a"));
		List<String> collections = new ArrayList<String>();

		for (WebElement basketItem : basketitems) {
			collections.add(basketItem.getText());

		}

		Assert.assertTrue(collections.contains(shirtName));

		ff.close();
		ff.quit();
	}
}
