package com.mns.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
/**
 * CAN USE PAGE OBJECT MODEL FOR EVERY SINGLE PAGE USING PAGE FACTORIES AND CALL THESE PAGES IN TESTS[BUT UNFORTUNATELY NO TIME AS WE GOT IMPORTANT RELEASE THIS WEEK REALLY BUSY]
 * @author bmeka
 *
 */
public class MainPage extends AbstractPage {

	@FindBy(how=How.XPATH,using="//*[@id='headerSection']/nav/ul/li[3]/ul/li/a/span[2]")
	@CacheLookup
	public WebElement basket;
	
	public MainPage(WebDriver driver) {
		super(driver);
		
	}

}
