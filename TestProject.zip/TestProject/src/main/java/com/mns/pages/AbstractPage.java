package com.mns.pages;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.mns.exceptions.CloseBrowserException;

public class AbstractPage {
	protected WebDriver driver = null;
	protected String pageUrl;
	protected String title;
	protected WebDriverWait wait;
	protected final Logger logger = Logger.getLogger("APP_LOGS");
	protected String screenShotsDestFolder;

	public AbstractPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/**
	 * Use this method to load a valid page/Base url entry point to the tests
	 * 
	 * @param pageUrl
	 */
	public void loadPage(String siteUrl) {
		logger.log(Level.INFO, "Loading Page ");
		driver.get(siteUrl);

		if (driver.getTitle().contains("Certificate Error: Navigation Blocked")) {
			driver.navigate()
					.to("javascript:document.getElementById('overridelink').click()");
			// As Interaction with IE controls are slow, default timeouts are
			// set to 30 secs
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}

	}

	/**
	 * Method returns current page title
	 * 
	 * @return String
	 */
	public String getTitle() {
		return driver.getTitle();
	}

	/**
	 * Method returns current page URL
	 * 
	 * @return String
	 */
	public String getCurrentUrl() {
		return driver.getCurrentUrl();
	}

	/**
	 * Method return the text value in the specified input/text area field
	 * 
	 * @param element
	 * @return String
	 * @throws ElementNotFoundException
	 */
	public String getInputFieldText(WebElement element)
			throws ElementNotFoundException {
		String value = null;
		if (isElementDisplayed(element)) {
			value = element.getAttribute("Value");
		} else {
			value = null;
		}
		return value;
	}

	/**
	 * Method checks whether the specified element is displayed on the page or
	 * not
	 * 
	 * @param element
	 * @return boolean
	 * @throws ElementNotFoundException
	 */
	public boolean isElementDisplayed(WebElement element) {

		try {
			if (element.isDisplayed()) {
				logger.log(Level.INFO, "Element [\"" + element.toString()
						+ "\"] is displayed");
				return true;
			} else {
				logger.log(Level.INFO, "Element [\"" + element.getText()
						+ "\"] is not displayed");
				return false;
			}

		} catch (NoSuchElementException e) {
			logger.log(Level.INFO, "Element [\"" + element.getText()
					+ "\"] is not found");
			takeScreenshot("isElementDisplayed_Err");
			return false;
		}

	}

	/**
	 * Method check whether the specified element is present on the page or not
	 * 
	 * @param element
	 * @return boolean
	 */
	public boolean isElementPresent(WebElement element) {

		try {
			element.isDisplayed();
			return true;

		} catch (NoSuchElementException e) {
			takeScreenshot("isElementPresent");
		}
		return false;
	}


	/**
	 * use this method to simulate user action pressing back button in the
	 * browser
	 */
	public void clickBrowserBackButton() {
		driver.navigate().back();
		logger.log(Level.INFO, "Browser back button clicked");
	}

	/**
	 * use this method to simulate user action pressing forward button in the
	 * browser
	 */
	public void clickBrowserForwardButton() {
		driver.navigate().forward();
		logger.log(Level.INFO, "Browser forward button clicked");
	}

	/**
	 * use this method to simulate user action pressing refresh button in the
	 * browser
	 */
	public void clickBrowserRefreshButton() {
		driver.navigate().refresh();
		logger.log(Level.INFO, "Browser refresh button clicked");
	}

	/**
	 * Use this method to close the browser and webdriver instance, also this
	 * method sets webdriver instace to null
	 * 
	 * @return boolean
	 * @throws CloseBrowserException
	 */
	public boolean closeBrowser() throws CloseBrowserException {
		boolean result = false;
		try {
			driver.close();
			driver.quit();
			driver = null;
			result = true;
		} catch (Exception e) {
			throw new CloseBrowserException(
					"Error closing browser or webdriver instance");
		}
		return result;
	}

	/*
	 * Use this method turn on implicit wait by specifying wait period including
	 * time units
	 */
	public void turnOnImplicitWait(long wait, TimeUnit unit) {

		driver.manage().timeouts().implicitlyWait(wait, unit);
	}

	/**
	 * Use this method to maximise the browser window
	 */
	public void maximiseWindow() {
		driver.manage().window().maximize();
	}

	public HashSet<String> getWindowHandles() {

		return (HashSet<String>) driver.getWindowHandles();
	}

	/*
	 * return webdriver instance to handle multiple windows etc
	 */
	public WebDriver getDriver() {

		return this.driver;
	}

	/*
	 * Use this method to get the instance of webdriverwait with wait time set
	 * to 20 seconds
	 */
	public WebDriverWait getWebDriverWait() {
		return new WebDriverWait(driver, 20);
	}

	/*
	 * Use this method to get the instance of webdriverwait with custom wait
	 * time seconds
	 */
	public WebDriverWait getWebDriverWait(int seconds) {
		return new WebDriverWait(driver, seconds);
	}
	
	/*
	 * use this method to take the screenshot of the current page and save it in
	 * the custom specified folder in png format
	 */
	public void takeScreenshot(String name) {
		String _name = name;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy_hh_mm_ss");
		String dateFileName = _name + "_" + sdf.format(new Date()) + ".png";
		// screenShotsDestFolder = System.getProperty("ScreenshotsFolder",
		// System.getProperty("user.dir")
		// + "\\output\\screenshots\\"+dateFileName);
		String destFiles = System.getProperty("user.dir")
				+ "\\tmp\\screenshots\\" + dateFileName;
		File screenShot = ((TakesScreenshot) driver)
				.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(screenShot, new File(destFiles));
			logger.log(Level.INFO, "Screenshot successfully captured");
		} catch (IOException e) {
			logger.log(Level.INFO,
					"Error capturing screenshot: " + e.getMessage());
		}
	}

}
