package runners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
/**
 * This is the test execution class
 * NOTE: PLEASE UPDATE THE FEATURES PATH WHEN PROJECT IS IMPORT INTO OTHER WORKSPACES
 * @author bmeka
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\bmeka\\workspace\\TestProject\\src\\main\\java\\com\\mns\\viewItems.feature", glue="com.mns.tests")
public class CucumberRunner {

}
